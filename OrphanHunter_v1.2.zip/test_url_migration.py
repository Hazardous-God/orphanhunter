#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Test script for URL migration functionality."""
import sys
import io
from pathlib import Path
import tempfile
import shutil

# Set UTF-8 output on Windows
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

# Add the OrphanHunter directory to path
sys.path.insert(0, str(Path(__file__).parent))

from utils.url_config import URLConfig
from analyzer.url_analyzer import URLAnalyzer, URLInstance
from operations.url_migrator import URLMigrator


def create_test_files(test_dir):
    """Create test PHP files with hardcoded URLs."""
    # Create test files
    (test_dir / "test1.php").write_text("""<?php
$url = "https://example.com/page.php";
$link = '<a href="https://example.com/about.php">About</a>';
$external = "https://google.com/search";
?>
""")
    
    (test_dir / "test2.php").write_text("""<?php
header("Location: https://example.com/dashboard.php");
$api = "https://example.com/api/users.php?id=1";
?>
""")
    
    (test_dir / "config.php").write_text("""<?php
define('BASE_URL', 'https://example.com');
$db_host = "localhost";
?>
""")
    
    print(f"✓ Created test files in {test_dir}")


def test_url_config():
    """Test URL configuration management."""
    print("\n" + "=" * 60)
    print("Testing URL Configuration")
    print("=" * 60)
    
    config = URLConfig("test-url-config.json")
    
    # Add domains
    config.add_internal_domain("https://example.com")
    config.add_legacy_domain("https://old-site.com")
    
    # Set format
    config.set_replacement_format("base_url")
    
    # Set file types
    config.set_enabled_file_types([".php", ".html"])
    
    # Verify
    assert "example.com" in config.get_all_internal_domains()
    assert config.get_replacement_format()[0] == "base_url"
    assert ".php" in config.get_enabled_file_types()
    
    print("✓ URL Config: domains, formats, and file types work")
    
    # Clean up
    Path("test-url-config.json").unlink(missing_ok=True)
    
    return config


def test_url_analyzer(test_dir):
    """Test URL analysis and detection."""
    print("\n" + "=" * 60)
    print("Testing URL Analyzer")
    print("=" * 60)
    
    # Create analyzer
    analyzer = URLAnalyzer(["example.com"], ["https://google.com"])
    
    # Scan files
    url_instances = analyzer.scan_directory(test_dir, [".php"], [])
    
    print(f"✓ Found {len(url_instances)} URLs")
    
    # Verify classification
    internal = analyzer.get_internal_urls()
    external = analyzer.get_external_urls()
    
    print(f"✓ Internal URLs: {len(internal)}")
    print(f"✓ External URLs: {len(external)}")
    
    # Extract domain from config
    config_php = test_dir / "config.php"
    domains = analyzer.extract_domain_from_config(config_php)
    assert "example.com" in domains
    print(f"✓ Extracted domains from config.php: {domains}")
    
    # Detect helpers
    helpers = analyzer.detect_helper_functions([config_php])
    print(f"✓ Detected {len(helpers)} helper functions")
    
    # Verification
    verification = analyzer.verify_classification()
    print(f"✓ Verification: {verification['internal_urls']} internal, {verification['external_urls']} external")
    
    assert len(internal) > 0, "Should find internal URLs"
    # External URLs may be 0 if they're whitelisted or if only internal domains are in test files
    print("✓ URL classification working correctly")
    
    return analyzer


def test_url_migrator(test_dir, analyzer):
    """Test URL migration and replacement."""
    print("\n" + "=" * 60)
    print("Testing URL Migrator")
    print("=" * 60)
    
    # Create migrator
    migrator = URLMigrator(test_dir, "base_url")
    
    # Plan replacements
    internal_urls = analyzer.get_internal_urls()
    change_records = migrator.plan_replacements(internal_urls, [])
    
    print(f"✓ Planned {len(change_records)} changes")
    
    # Verify change records
    assert len(change_records) > 0, "Should have change records"
    
    for record in change_records[:3]:
        print(f"  - {record.file_path}:{record.line_number}")
        print(f"    OLD: {record.old_url}")
        print(f"    NEW: {record.new_url}")
    
    # Test without actually applying (would modify test files)
    print("✓ Change records generated successfully")
    
    # Test report generation
    report = migrator.generate_report()
    assert "MIGRATION REPORT" in report
    print("✓ Migration report generated")
    
    return migrator


def test_integration():
    """Run integration tests."""
    print("\n" + "=" * 60)
    print("URL Migration Tool - Integration Test")
    print("=" * 60)
    
    # Create temporary test directory
    test_dir = Path(tempfile.mkdtemp(prefix="url_migration_test_"))
    print(f"\nTest directory: {test_dir}")
    
    try:
        # Create test files
        create_test_files(test_dir)
        
        # Test components
        config = test_url_config()
        analyzer = test_url_analyzer(test_dir)
        migrator = test_url_migrator(test_dir, analyzer)
        
        print("\n" + "=" * 60)
        print("✓ ALL TESTS PASSED")
        print("=" * 60)
        print("\nURL Migration Tool is ready to use!")
        print("\nKey Features Verified:")
        print("  ✓ URL detection and classification")
        print("  ✓ Domain extraction from config.php")
        print("  ✓ Helper function detection")
        print("  ✓ Migration planning and change tracking")
        print("  ✓ Configuration management")
        print("\nTo use the tool:")
        print("  1. Run: python system-mapper.py")
        print("  2. Go to 'Generate Docs' tab")
        print("  3. Click 'Open URL Migration Tool'")
        
        return True
        
    except AssertionError as e:
        print(f"\n✗ TEST FAILED: {e}")
        return False
    
    except Exception as e:
        print(f"\n✗ ERROR: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    finally:
        # Clean up
        if test_dir.exists():
            shutil.rmtree(test_dir)
            print(f"\n✓ Cleaned up test directory")


if __name__ == "__main__":
    success = test_integration()
    sys.exit(0 if success else 1)

