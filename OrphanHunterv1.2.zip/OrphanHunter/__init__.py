"""OrphanHunter - PHP Project Migration & Cleanup Tool."""
__version__ = "1.2"
__author__ = "PropertyXRP"

